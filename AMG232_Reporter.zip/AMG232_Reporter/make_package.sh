#!/usr/bin/env bash
ROOT=$(pwd)
NAME='AMG232_Reporter.zip'

pushd $ROOT/../
zip -r --exclude=*.git* --exclude=*test* --exclude=*tmp* --exclude=*resource/annovar_db* --exclude=*$0* $NAME AMG232_Reporter
popd
